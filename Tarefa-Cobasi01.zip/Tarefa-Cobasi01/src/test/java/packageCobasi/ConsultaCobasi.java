package packageCobasi;


import cucumber.api.java.After;
import cucumber.api.java.Before;

import cucumber.api.java.pt.Dado;
import cucumber.api.java.pt.Entao;
import cucumber.api.java.pt.Quando;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

public class ConsultaCobasi {

    static String url;
    WebDriver driver;
    String pastaPrint = "evidencias/" + new SimpleDateFormat("yyyy-MM-dd HH-mm").format(Calendar.getInstance().getTime()) + "/";

    public void tirarPrint(String nomePrint) throws IOException {
        File foto = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(foto,new File(pastaPrint + nomePrint +".png"));
    }

    @Before
    public void iniciar(){
        url = "https://www.cobasi.com.br/";
        System.setProperty("webdriver.chrome.driver","drivers/chrome/87/chromedriver.exe");
        ChromeOptions co = new ChromeOptions();
        co.addArguments("--disable-notifications");
        driver = new ChromeDriver(co);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(20000, TimeUnit.MILLISECONDS);
        System.out.println("Passo 0 - Preparou o setup");
    }

    @After
    public void finalizar(){
        driver.quit();
        System.out.println("Passo 6 - Fechou o browser");
    }


    @Dado("^que acesso o site da Cobasi$")
    public void queAcessoOSiteDaCobasi() throws IOException {
        driver.get(url);
        tirarPrint("01 - Acesso ao site do Google Brasil");
        System.out.println("Passo 1 - Acessou o site da Cobasi");
    }

    @Quando("^procuro por \"([^\"]*)\" e pressiono Enter$")
    public void procuro_por_e_pressiono_Enter(String produto) throws IOException {
        driver.findElement(By.cssSelector("input.fulltext-search-box.ui-autocomplete-input.neemu-search-field")).sendKeys(produto + Keys.ENTER);
        tirarPrint("02 - Pesquisou pelo produto Ra��o");
        System.out.println("Passo 2 - Pesquisou pelo produto Ra��o");
    }

    @Entao("^exibe a lista de produtos relacionados a \"([^\"]*)\"$")
    public void exibe_a_lista_de_produtos_relacionados_a(String termo) throws IOException {
        tirarPrint("03 - Exibe lista de op��es de ra��o");
        System.out.println("Passo 3 - Exibe lista de op��es de ra��o");

    }

    @Quando("^seleciono o \"([^\"]*)\" da lista$")
    public void seleciono_o_da_lista(String produtoDescricao) throws IOException {
        driver.findElement(By.xpath("//a[contains(text(),'Ra��o N&D Prime C�es Adultos Mini Cordeiro')]")).click();
        tirarPrint("04 - Selecionado a Ra��o N&D Prime C�es Adultos Mini Cordeiro");
        System.out.println("Passo 4 - Selecionado a Ra��o N&D Prime C�es Adultos Mini Cordeiro");

    }

    @Entao("^verifico a \"([^\"]*)\" com o \"([^\"]*)\" e \"([^\"]*)\"$")
    public void verifico_a_com_o_e(String marca, String precoNormal, String precoAssinante) throws IOException {
        assertEquals(marca,driver.findElement(By.cssSelector("div.product__brand")).getText());
        assertEquals(precoNormal,driver.findElement(By.cssSelector("span.d-block.price__por")).getText());
        assertEquals(precoNormal,driver.findElement(By.cssSelector("span.price__assinatura-price")).getText());
        //tirarPrint("  ");
        //System.out.println("Passo 5 - Verificou a " + marca + "o preco normal " + precoNormal + "e o preco de assinante" + precoAssinante +);


    }

}
